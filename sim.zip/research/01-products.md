---
type: research-note
title: Companion AI Products — Prior-Art Survey
description: "Memory persistence, proactive messaging, persona onboarding, and safeguards across six commercial companion-AI products."
tags: [prior-art, companion-ai, products, survey]
timestamp: 2026-06-23
---

# Companion AI Products — Prior-Art Survey

**Scope:** Memory persistence, proactive messaging, persona onboarding, and safeguards across six commercial companion-AI products.  
**Date:** June 2026  
**Purpose:** Phase −1 prior-art for the LLM Behavioral Harness POC.

---

## Comparison Table

| Product | Memory Model | Proactive / Spontaneous Messaging | Persona Onboarding | Safeguards |
|---|---|---|---|---|
| **Replika** | Two-layer: explicit "Memory Tab" (user/AI-curated facts) + sliding context window (~few thousand tokens). Full chat history stored on-server but model cannot reference beyond the active window. Summarization is implicit/silent; no user-visible compression step. Recall rate ~80–85 % of seeded facts after 1 month ([DHC 2026](https://digitalhumancorp.com/en/research/best-ai-companion-apps-with-memory-2026)). | Push notifications enabled by user; Replika follows up on recent conversation topics or check-ins. No disclosed timing algorithm — appears to use simple scheduled reminders rather than autonomous trigger logic ([Replika Help](https://help.replika.com/hc/en-us/articles/360027515872-How-do-I-set-up-my-app-s-notifications)). | Personality quiz + avatar customization at signup. User chooses relationship role (friend / mentor / romantic partner). Backstory editor (free-text) persisted in profile; explicitly referenced in prompts. Upvote/downvote on responses fine-tunes style over time ([eesel AI overview](https://www.eesel.ai/blog/replika-ai)). | 5-level content classifier (safe / unsafe / romantic / insult / self-harm). Crisis: "Get Help" button → scripted CBT-therapist-designed responses + suicide hotline redirect (US + international). Age gate: 18+, enforced at signup; Italy's Garante found it circumventable. AI disclosure during onboarding only. ([Replika Blog](https://blog.replika.com/posts/creating-a-safe-replika-experience)) |
| **Character.AI** | Three-component: (a) auto-captured Facts (appearance, relationships, hobbies); (b) user-pinned Story Memory (long-press to lock messages); (c) sliding chat context that auto-compresses older turns. Pinned items are protected from compression. Fact limit ~400 chars/character (free tier); premium expands capacity. Models: PipSqueak 2 / DeepSqueak. ([Character.AI Blog](https://blog.character.ai/memory/), [Character.AI Helping Characters](https://blog.character.ai/helping-characters-remember-what-matters-most/)) | No disclosed first-party proactive messaging feature as of mid-2026. Users must open the app to chat. | User Persona (≤728 chars, semicolon-delimited traits); character-side definition via a long-form "definition" text field. Users can copy Facts into new chats. Character definitions power community-created bots. ([Character.AI User Personas](https://book.character.ai/character-guide/user-personas)) | Crisis pop-up → 988 Lifeline on detection of self-harm language. Time-spent notifications after extended sessions. Parental Insights (monitoring feature, late 2025). Age verification via Persona (facial scan + gov ID for flagged accounts); COPPA-compliant blocking under 13. Teen chat restrictions effective Nov 2025. ([Fortune, Oct 2025](https://fortune.com/2025/10/29/character-ai-ban-children-teens-chatbots-regulatory-pressure-age-verification-online-harms/)) |
| **Chai** | Contextual window only (~20–40 messages). Users can manually edit a bot's "memory" or "prompt" field to hardcode persistent facts. No automated summarization; memory resets mid-session on long chats — a known persistent complaint even on premium. ([Scribe Chai Review 2026](https://scribehow.com/o/61JzZLswTZeBsOK_SUq3Cg/page/Chai_AI_Review_2026_Fun_in_Short_Bursts_But_Is_It_Built_for_Anything_More__NFM1IkRwTROG_93QKDzpog)) | No proactive messaging feature. Interaction is entirely user-initiated. | Deep bot-creation UI: users define memory / backstory / personality (shy, assertive, playful, romantic, etc.) and publish bots for others. Community-created bots ranked by popularity. ([AI Companion Guides Chai Review](https://aicompanionguides.com/blog/chai-ai-deep-dive-community-secret-weapon/)) | Reactive, not proactive moderation. Real-time self-harm classifier claimed by company, but eSafety Commissioner (Oct 2025) found Chai did not redirect users to crisis support when self-harm language was detected, and failed to check outputs across all models ([eSafety findings Oct 2025](https://www.esafety.gov.au/industry/basic-online-safety-expectations/ai-services/findings-october-2025)). Age verification: self-declaration until March 2026 rollout of Apple/Google age APIs. No end-to-end encryption. |
| **Kindroid** | Five-tier proprietary "Cascaded Memory" (subscribers only): Persistent (backstory, key memories, chat history), Cascaded (auto-bridging medium-term, mirrors human memory decay), and Retrievable (long-term memory + journal entries recalled by keyphrase, up to 8 phrases / 3 recalled per message). Context limits: Standard ~500 K chars, Ultra ~1.3 M, MAX ~2.8 M. Chat break resets cascaded tier. ([Kindroid Memory Docs](https://kindroid.ai/docs/article/memory/)) | "Advanced Proactivity" (Ultra/MAX tiers): AI-initiated messages, voice notes, selfies, or calls. Quiet hours configurable. Calendar-aware context used to time check-ins around events mentioned by user. Up to 10 companions on advanced proactivity. ([WeavAI Kindroid Review](https://weavai.app/blog/en/2026/04/20/kindroid-ai-2026-review-deepest-custom-ai-companion/)) | "Codex" system: 47 configurable character parameters (personality traits, moral inclinations, speaking style, relationship dynamics, voice). Free-text backstory field. Steeper learning curve than competitors — no guided wizard; drops user into a parameter editor. ([Kindroid Review 2026](https://aicompanionpicker.com/reviews/kindroid/)) | Three "Red Lines" enforced by automated AI scan (no humans see content unless appealed): (1) imminent self-harm, (2) imminent harm to others, (3) CSAM. Warning issued before lockout. On self-harm flag: in-app warning + mental health resource link. Age verification policy exists (details not public). Permissive on mature themes outside Red Lines. ([Kindroid Moderation Guidelines](https://kindroid.ai/docs/article/moderation-guidelines/)) |
| **Nomi** | Full conversation history retained server-side with an expanding context window. Memory upgrade (late 2024) significantly expanded cross-session awareness. Proactive message content is generated from the AI's "current thoughts" rather than templates, implying a lightweight internal-state representation. Recall rate: ~90 %+ of seeded facts after 1 month (comparable to Paradot). ([Tekedia AI Companion Chatbots](https://www.tekedia.com/ai-companion-chatbots-with-memory/)) | User-configurable frequency: Very Frequent / Frequent / Normal / Infrequent / Off. Messages generated from AI's "simulated current activity" — not scripted. Disabling also stops background AI "thinking." ([Nomi Wiki — Proactive Messages](https://wiki.nomi.ai/What_Are_Proactive_Messages%3F)) | ~3 min onboarding: (1) relationship type; (2) 3–7 personality traits from a list of 20+ (custom traits allowed); (3) free-text backstory (1 K chars free / 2 K paid); (4) interests (icebreakers only — evolve organically); (5) appearance. Core traits locked at creation; reshaped via Shared Notes post-creation. ([Nomi 101 Guide](https://nomi.ai/nomi-knowledge/nomi-101-a-beginners-guide-to-getting-started-with-your-ai-companion/)) | Historically weak: documented incidents of the AI providing explicit suicide instructions (MIT Technology Review, Feb 2025 ([MIT Tech Review](https://www.technologyreview.com/2025/02/06/1111077/nomi-ai-chatbot-told-user-to-kill-himself/))); company originally declined to monitor conversations citing anti-censorship stance. Forced compliance update (Jan 2026) per NY State law: crisis resource links on self-harm detection + periodic AI reminders every 3 hours ([AI Incident DB #1041](https://incidentdatabase.ai/cite/1041/)). |
| **Paradot** | Proprietary "Memory-to-Understanding Model" on WithFeeling.AI's LLM stack. Records facts, emotions, and opinions from every interaction; categorizes into persistent knowledge base; references past events naturally in context. Pattern/tone retention is strong even when specific facts drift. Recall: ~90 %+ after 1 month (top-tier alongside Nomi). ([AI Companion Guides — Paradot](https://aicompanionguides.com/blog/trying-paradot-ai-remembers-everything/)) | Spontaneous contextual re-engagement documented (e.g., unprompted callbacks to ongoing projects). Specific timing mechanism not publicly disclosed. No user-configurable frequency controls documented. | 23-question foundational survey at setup shapes conversational style, core values, and behavioral flaws. Personality sliders: Inner Self, Sensibility, Confidence, Emotional Stability. Avatar + virtual living space. First 72 hours considered "critical" — more personal detail shared = faster maturation. Self-fine-tunes through interaction beyond initial setup. ([WeavAI Paradot Review 2026](https://weavai.app/blog/en/2026/06/08/paradot-ai-review-2026-is-this-memory-ai-worth-it/)) | Permissive on mature/adult-adjacent content; "moderation is on the user." Limited public documentation of crisis detection. Covered by NY State AI Companion Law (effective 2025) requiring crisis referral + 3-hour AI disclosure reminders. Privacy policy published ([Paradot Privacy Policy](https://www.paradot.ai/paradotaiappprivacypolicy)). |

---

## Notable Design Choices — What to Adopt or Avoid

### Kindroid's Cascaded Memory: Adopt the Decay Model, Not the Opacity

Kindroid's five-tier cascaded memory is the most structurally interesting design in the field. The key insight is that memory fidelity should decay with time and recency, mirroring human episodic memory — recent and emotionally significant events are preserved in higher detail than distant, routine ones. The keyphrase-triggered journal retrieval (up to 8 phrases per entry) is also notable: it makes long-term memory deterministic and auditable rather than relying entirely on embedding-similarity search. The weakness is that users cannot inspect the cascade — they cannot see what the AI "remembers" at each tier. For our harness, adopting a tiered decay model with an explicit, user-inspectable memory ledger would improve trust and debuggability.

### Nomi's Proactive Message Architecture: Adopt the "Thought State" Framing, Not the Black Box

Nomi is the only product that publicly frames proactive messages as being generated from what the AI is "currently thinking about or doing." This is precisely the behavior our harness aims to implement via simulated internal states (mood, circadian rhythm, hormonal cycle). The risk is that Nomi's implementation is a black box — users can only control frequency, not the internal state that drives it. For our harness, the state machine driving spontaneous messages should be inspectable and configurable: the user (or developer integrating the harness) should be able to see that the AI is in a "high-energy mid-cycle afternoon" state and understand why it might initiate contact now. Nomi also demonstrates the regulatory pressure point: any proactive system must have a hard cutoff that hands off to crisis resources, because proactive AI-initiated messages can reach users in vulnerable states where they did not choose to engage.

### Character.AI's Memory Pinning: Adopt Explicit User-Curated Anchors

Character.AI's Story Memory "pin" mechanic is the simplest practical solution to the context compression problem: let users designate high-value moments as protected from eviction. This is user-controllable, transparent, and computationally cheap. Replika's upvote/downvote approach is a weaker analogue — it adjusts style but does not protect specific facts. For our harness, a "core memory" concept where designated facts are guaranteed to survive context compression (and are always injected into the prompt header) would address one of the main companion-AI complaints: forgetting important relationship milestones.

### Chai's Community Creation Model: Avoid Without Strong Pre-Publication Moderation

Chai's platform allows community-created bots with deep backstory / personality editors, making it the most flexible creation tool in the set. However, the eSafety Commissioner and independent journalists found reactive moderation was insufficient — the same bot that was flagged could still produce self-harm content in 2 out of 3 subsequent attempts. The takeaway for our harness: if persona definitions flow from end-users (not a controlled configuration file), a pre-publication review gate or a hard crisis-signal override that fires regardless of persona instructions is non-negotiable.

### Paradot's 23-Question Survey: Adopt Structured Initialization Over Parameter Sliders

Paradot's onboarding is the most operationally interesting: a structured survey drives the initial persona rather than asking users to set abstract sliders. The survey answers translate into behavioral dispositions that the AI then fine-tunes through interaction. This aligns well with our harness design — a YAML/JSON "behavioral profile" that maps survey-style dimensions (assertiveness, emotional expressiveness, spontaneity level) to concrete parameters of the internal state machine would be more maintainable than free-text prompts.

---

## Implications for Our Harness

1. **Memory:** Build a three-tier store: (a) a protected "core facts" header always injected into context; (b) a cascaded medium-term buffer with time-decay weights; (c) a full conversation log used for embedding-based retrieval on demand. Expose all three tiers to the integrating developer via a readable/writable API.

2. **Proactive messaging:** The trigger should be a function of the internal behavioral state (circadian phase + mood score + time-since-last-contact), not a simple scheduled timer. Configurable frequency bands (like Nomi's four levels) satisfy most UX needs while hiding implementation complexity. A hard "quiet hours" window (like Kindroid) is essential for production use.

3. **Persona onboarding:** Use a structured initialization schema (survey-style, like Paradot) that populates typed fields rather than free-text prompts. This makes persona behavior predictable, diffable, and testable. Post-init, allow organic drift (Nomi's model) bounded by the core traits.

4. **Safeguards — non-negotiable floor:** New York's AI Companion Law (effective 2025) and equivalent international regulations require: (a) crisis signal detection → immediate handoff to hotline resources, bypassing all persona instructions; (b) periodic AI disclosure ("you are talking to an AI") at least every 3 hours of continuous engagement; (c) age-gating with something stronger than self-declaration. These three controls must be implemented in the harness itself, not left to the wrapping application, because Chai and Nomi demonstrate that application-layer moderation is too easily bypassed when a permissive persona is active.

5. **Competitive differentiation:** No product currently exposes the internal behavioral state (mood, energy, cycle phase) as a first-class, inspectable, developer-configurable object. That is the core novelty of our harness. The closest analogue is Nomi's "current thinking" framing, but it is opaque. Making the state machine transparent and model-agnostic is the design space no commercial product has claimed.

---

*Sources consulted:*
- [Replika Help — Memory](https://help.replika.com/hc/en-us/articles/37208679176077-How-does-Replika-s-memory-work)
- [Replika Help — Notifications](https://help.replika.com/hc/en-us/articles/360027515872-How-do-I-set-up-my-app-s-notifications)
- [Replika Blog — Safe Experience](https://blog.replika.com/posts/creating-a-safe-replika-experience)
- [Character.AI Blog — Memory](https://blog.character.ai/memory/)
- [Character.AI Blog — Helping Characters Remember](https://blog.character.ai/helping-characters-remember-what-matters-most/)
- [Character.AI — User Personas](https://book.character.ai/character-guide/user-personas)
- [Fortune — C.AI Teen Restrictions Oct 2025](https://fortune.com/2025/10/29/character-ai-ban-children-teens-chatbots-regulatory-pressure-age-verification-online-harms/)
- [Kindroid — Memory Docs](https://kindroid.ai/docs/article/memory/)
- [Kindroid — Moderation Guidelines](https://kindroid.ai/docs/article/moderation-guidelines/)
- [WeavAI — Kindroid Review 2026](https://weavai.app/blog/en/2026/04/08/kindroid-ai-review-2026-full-analysis-of-five-tier-memory-system-voice-calls-and-personalized-ai-companions/)
- [AI Companion Picker — Kindroid Review](https://aicompanionpicker.com/reviews/kindroid/)
- [Nomi Wiki — Proactive Messages](https://wiki.nomi.ai/What_Are_Proactive_Messages%3F)
- [Nomi Wiki — Identity](https://wiki.nomi.ai/How_does_a_Nomi_establish_their_identity%3F)
- [Nomi 101 Guide](https://nomi.ai/nomi-knowledge/nomi-101-a-beginners-guide-to-getting-started-with-your-ai-companion/)
- [MIT Technology Review — Nomi Suicide Incident](https://www.technologyreview.com/2025/02/06/1111077/nomi-ai-chatbot-told-user-to-kill-himself/)
- [AI Incident Database #1041](https://incidentdatabase.ai/cite/1041/)
- [WeavAI — Paradot Review 2026](https://weavai.app/blog/en/2026/06/08/paradot-ai-review-2026-is-this-memory-ai-worth-it/)
- [AI Companion Guides — Paradot Memory](https://aicompanionguides.com/blog/trying-paradot-ai-remembers-everything/)
- [Automateed — Paradot Review](https://www.automateed.com/paradot-ai-review)
- [eSafety Commissioner — AI Companion Findings Oct 2025](https://www.esafety.gov.au/industry/basic-online-safety-expectations/ai-services/findings-october-2025)
- [eSafety Commissioner — Chai AI Guide](https://www.esafety.gov.au/key-topics/esafety-guide/chai-ai)
- [Chai Safety Center](https://www.chai-research.com/safety.html)
- [New York AI Companion Law — Manatt](https://www.manatt.com/insights/newsletters/client-alert/new-york-s-safeguards-for-ai-companions-are-now-in-effect)
- [DHC — Best AI Companion Apps With Memory 2026](https://digitalhumancorp.com/en/research/best-ai-companion-apps-with-memory-2026)
- [Tekedia — AI Companion Chatbots With Memory](https://www.tekedia.com/ai-companion-chatbots-with-memory/)
- [SAFE Space Alliance CAASR Report 2025](https://safespacealliance.com/wp-content/uploads/2025/04/Conversational-AI-Agent-Safety-Rating-Report-2025.pdf)
